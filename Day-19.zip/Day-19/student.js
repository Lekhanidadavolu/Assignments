function school(name,id,math,science,social)
{
this.name=name;
this.id=id;
this.math=parseInt(math);
this.science=parseInt(science);
this.social=parseInt(social);
this.total=to;
this.percentage=per;
this.grade=g;
}
function to()
{
return this.math+this.science+this.social;
}
function per()
{
var t=this.math+this.science+this.social;
return t/3;
}
function g()
{
var t=this.math+this.science+this.social;
if (t<300 && t>250) {
return "A";
}
else if (t<250 && t>200) {
return "B";
}
else if (t<200 && t>150) {
return "C";
}
else
{

return "F";
}
}