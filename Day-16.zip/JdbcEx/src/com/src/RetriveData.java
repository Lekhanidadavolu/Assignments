package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class RetriveData {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String url="jdbc:mysql://localhost:3306/lekhadb";
		String user="root";
		String password="Root";
		
		try(Connection con=DriverManager.getConnection(url,user,password))
		{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from employee");
		while(rs.next())
		{
		     System.out.println(rs.getInt("empid")+" "+rs.getString("empname")+" "+rs.getString("empaddress")+" "+rs.getFloat("empsalary"));;
		}
		System.out.println("end of program");
	    
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
}
}
